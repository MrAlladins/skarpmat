<?php
// Ange din Google Translate API-nyckel här
$googleApiKey = "AIzaSyARJKB_tIgLFR5oiRFSSFEm3Yd2MetRY5c";
?>